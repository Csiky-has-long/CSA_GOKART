﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace GOKART
{
    class Versenyzo
    {
        public string Vezeteknev { get; set; }
        public string Keresztnev { get; set; }
        public DateTime SzuletesiIdo { get; set; }
        public bool Elmúlt18 { get; set; }
        public string VersenyzoAzonosito { get; set; }
        public string Email { get; set; }

        public DateTime? FoglalasKezdete { get; set; }
        public DateTime? FoglalasVege { get; set; }
    }

    internal class Program
    {
        static Random random = new Random();

        static void Main(string[] args)
        {
            string nev = "CSÁ Gokartpálya";
            string cim = "Tihany, Kossuth Lajos u. 11, 8237";
            string telefonszam = "+36-20-257-76534";
            string weboldal = "csa_gokart.hu";

            Console.OutputEncoding = Encoding.UTF8;

            Console.WriteLine("==============================================");
            Console.WriteLine("     GOKART IDŐPONTFOGLALÓ - EGYÉNI");
            Console.WriteLine("==============================================");
            Console.WriteLine();

            Console.WriteLine("Programkészítő monogramja: CSÁ");
            Console.WriteLine("Kezdeti dátum: 2026.09.21.");
            Console.WriteLine("Projekt neve: Gokart időpontfoglaló - Egyéni kisprojekt");
            Console.WriteLine();

            Console.WriteLine("GOKARTPÁLYA ADATAI");
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine($"Név:         {nev}");
            Console.WriteLine($"Cím:         {cim}");
            Console.WriteLine($"Telefonszám: {telefonszam}");
            Console.WriteLine($"Weboldal:    {weboldal}");
            Console.WriteLine();

            string[] vezeteknevek = File.Exists("vezeteknevek.txt")
                ? File.ReadAllText("vezeteknevek.txt").Split(',').Select(x => x.Trim().Trim('\'')).Where(x => x.Length > 0).ToArray()
                : new[] { "Nagy", "Kovács", "Tóth", "Szabó", "Horváth" };

            string[] keresztnevek = File.Exists("keresztnevek.txt")
                ? File.ReadAllText("keresztnevek.txt").Split(',').Select(x => x.Trim().Trim('\'')).Where(x => x.Length > 0).ToArray()
                : new[] { "Péter", "Anna", "Gábor", "Katalin", "Tamás" };

            int versenyzokSzama = random.Next(10, 30);
            List<Versenyzo> versenyzok = new List<Versenyzo>();

            DateTime maiDatum = DateTime.Today;
            int maxNapok = DateTime.DaysInMonth(maiDatum.Year, maiDatum.Month) - maiDatum.Day + 1;

            for (int i = 0; i < versenyzokSzama; i++)
            {
                string vezeteknev = vezeteknevek[random.Next(vezeteknevek.Length)];
                string keresztnev = keresztnevek[random.Next(keresztnevek.Length)];

                DateTime kezdodatum = new DateTime(1960, 1, 1);
                DateTime vegdatum = new DateTime(2020, 12, 31);
                int napok = (vegdatum - kezdodatum).Days;
                DateTime szuletesiIdo = kezdodatum.AddDays(random.Next(napok + 1));

                Versenyzo versenyzo = new Versenyzo
                {
                    Vezeteknev = vezeteknev,
                    Keresztnev = keresztnev,
                    SzuletesiIdo = szuletesiIdo,
                    Elmúlt18 = szuletesiIdo.AddYears(18) <= DateTime.Today
                };

                string ekezetNelkulVezeteknev = EkezetNelkul(vezeteknev);
                string ekezetNelkulKeresztnev = EkezetNelkul(keresztnev);
                string datum = szuletesiIdo.ToString("yyyyMMdd");

                versenyzo.VersenyzoAzonosito = $"GO-{ekezetNelkulVezeteknev}{ekezetNelkulKeresztnev}-{datum}";
                versenyzo.Email = $"{ekezetNelkulVezeteknev.ToLower()}.{ekezetNelkulKeresztnev.ToLower()}@gmail.com";

                if (random.Next(100) < 60)
                {
                    int véletlenNapOffset = random.Next(0, maxNapok);
                    int véletlenOra = random.Next(8, 18);
                    int orak = random.Next(1, 3);

                    versenyzo.FoglalasKezdete = maiDatum.AddDays(véletlenNapOffset).AddHours(véletlenOra);
                    versenyzo.FoglalasVege = versenyzo.FoglalasKezdete.Value.AddHours(orak);
                }

                versenyzok.Add(versenyzo);
            }

            bool foprogramFut = true;
            while (foprogramFut)
            {
                Console.Clear();
                Console.WriteLine("==============================================");
                Console.WriteLine("         GOKART FOGLALÁSI RENDSZER");
                Console.WriteLine("==============================================");

                IdopontokMegjelenitese(versenyzok);

                Console.WriteLine("VÁLASSZ AZ ALÁBBI LEHETŐSÉGEK KÖZÜL:");
                Console.WriteLine("1. Versenyzők listázása");
                Console.WriteLine("2. Új foglalás / Foglalás módosítása (Átfoglalás)");
                Console.WriteLine("3. Foglalás törlése");
                Console.WriteLine("4. Kilépés");
                Console.Write("\nVálasztás (1-4): ");

                string valasz = Console.ReadLine();

                switch (valasz)
                {
                    case "1":
                        VersenyzokListazasa(versenyzok);
                        break;
                    case "2":
                        FoglalasBeallitasaEsModositasa(versenyzok);
                        break;
                    case "3":
                        FoglalasTorlese(versenyzok);
                        break;
                    case "4":
                        foprogramFut = false;
                        break;
                    default:
                        Console.WriteLine("Érvénytelen választás! Nyomj ENTER-t...");
                        Console.ReadLine();
                        break;
                }
            }

            Console.WriteLine("\nA program véget ért.");
            Console.ReadKey();
        }

        static void IdopontokMegjelenitese(List<Versenyzo> versenyzok)
        {
            DateTime maiDatum = DateTime.Today;
            DateTime honapVege = new DateTime(
                maiDatum.Year,
                maiDatum.Month,
                DateTime.DaysInMonth(maiDatum.Year, maiDatum.Month));

            Console.WriteLine("\n--- AKTUÁLIS FOGLALTSÁGI TÁBLÁZAT ---");
            Console.Write("".PadRight(12));

            for (int ora = 8; ora < 19; ora++)
            {
                string sáv = $"{ora}-{ora + 1}";
                Console.Write(sáv.PadRight(6));
            }

            Console.WriteLine();

            for (DateTime nap = maiDatum; nap <= honapVege; nap = nap.AddDays(1))
            {
                Console.Write(nap.ToString("yyyy.MM.dd.").PadRight(12));

                for (int ora = 8; ora < 19; ora++)
                {
                    DateTime kezdet = nap.Date.AddHours(ora);
                    DateTime vege = kezdet.AddHours(1);

                    int foglaltak = versenyzok.Count(v =>
                        v.FoglalasKezdete.HasValue &&
                        v.FoglalasVege.HasValue &&
                        v.FoglalasKezdete.Value < vege &&
                        v.FoglalasVege.Value > kezdet
                    );

                    if (foglaltak == 0)
                    {
                        Console.BackgroundColor = ConsoleColor.Green;
                    }
                    else if (foglaltak >= 20)
                    {
                        Console.BackgroundColor = ConsoleColor.Red;
                    }
                    else
                    {
                        Console.BackgroundColor = ConsoleColor.DarkYellow;
                    }

                    Console.Write("      ");
                    Console.ResetColor();
                }

                Console.WriteLine();
            }
            Console.WriteLine("\nJelmagyarázat: [Zöld = Szabad]  [Sárga = Van még hely]  [Piros = Megtelt (20/20)]\n");
        }

        static void VersenyzokListazasa(List<Versenyzo> versenyzok)
        {
            Console.WriteLine("\n================ VERSENYZŐK LISTÁJA ================");
            int sorszam = 1;
            foreach (Versenyzo v in versenyzok)
            {
                string foglalasInfo = v.FoglalasKezdete.HasValue
                    ? $"{v.FoglalasKezdete:yyyy.MM.dd. HH:mm} - {v.FoglalasVege:HH:mm}"
                    : "Nincs foglalás";

                Console.WriteLine($"{sorszam}. {v.Vezeteknev} {v.Keresztnev} | ID: {v.VersenyzoAzonosito} | Foglalás: {foglalasInfo}");
                sorszam++;
            }
            Console.WriteLine("\nNyomj ENTER-t a visszalépéshez!");
            Console.ReadLine();
        }

        static void FoglalasBeallitasaEsModositasa(List<Versenyzo> versenyzok)
        {
            Console.WriteLine("================ FOGLALÁS / ÁTFOGLALÁS MÓDOSÍTÁSA ================");
            Console.Write("Add meg a versenyző azonosítóját (vagy nyomj ENTER-t a megszakításhoz): ");
            string azonosito = Console.ReadLine()?.Trim();

            if (string.IsNullOrEmpty(azonosito)) return;

            Versenyzo kivalasztott = versenyzok.FirstOrDefault(
                v => v.VersenyzoAzonosito.Equals(azonosito, StringComparison.OrdinalIgnoreCase)
            );

            if (kivalasztott == null)
            {
                Console.WriteLine("Nincs ilyen azonosítójú versenyző!");
                Console.WriteLine("Nyomj ENTER-t a folytatáshoz...");
                Console.ReadLine();
                return;
            }

            Console.WriteLine($"\nKiválasztva: {kivalasztott.Vezeteknev} {kivalasztott.Keresztnev}");
            if (kivalasztott.FoglalasKezdete.HasValue)
            {
                Console.WriteLine($"Jelenlegi foglalása: {kivalasztott.FoglalasKezdete:yyyy.MM.dd. HH:mm} - {kivalasztott.FoglalasVege:HH:mm}");
            }
            else
            {
                Console.WriteLine("A versenyzőnek jelenleg nincs foglalása.");
            }

            Console.WriteLine("\nADJ MEG ÚJ IDŐPONTOT:");

            DateTime datum;
            while (true)
            {
                Console.Write("Dátum (hónap.nap, pl. 09.26): ");
                string datumSzoveg = Console.ReadLine();

                if (DateTime.TryParseExact(datumSzoveg, "MM.dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime beirtDatum))
                {
                    datum = new DateTime(DateTime.Today.Year, beirtDatum.Month, beirtDatum.Day);
                    break;
                }
                Console.WriteLine("Hibás formátum! Használd a HÓ.NAP formátumot (pl. 09.26)!");
            }

            int kezdoOra;
            while (true)
            {
                Console.Write("Kezdési idő órában (8-18): ");
                if (int.TryParse(Console.ReadLine(), out kezdoOra) && kezdoOra >= 8 && kezdoOra <= 18)
                {
                    break;
                }
                Console.WriteLine("A nyitvatartás miatt 8 és 18 közötti órát adj meg!");
            }

            int orak;
            while (true)
            {
                Console.Write("Hány órára foglal? (1 vagy 2): ");
                if (int.TryParse(Console.ReadLine(), out orak) && (orak == 1 || orak == 2))
                {
                    break;
                }
                Console.WriteLine("Csak 1 vagy 2 órára lehet foglalni!");
            }

            DateTime foglalasKezdete = datum.Date.AddHours(kezdoOra);
            DateTime foglalasVege = foglalasKezdete.AddHours(orak);

            DateTime honapVege = new DateTime(
                DateTime.Today.Year,
                DateTime.Today.Month,
                DateTime.DaysInMonth(DateTime.Today.Year, DateTime.Today.Month));

            if (foglalasKezdete.Date < DateTime.Today || foglalasKezdete.Date > honapVege)
            {
                Console.WriteLine("\nHiba: Csak a mai naptól a hónap végéig lehet foglalni!");
                Console.ReadLine();
                return;
            }

            if (foglalasKezdete.Hour < 8 || foglalasVege.Hour > 19)
            {
                Console.WriteLine("\nHiba: A pálya 08:00 és 19:00 között tart nyitva!");
                Console.ReadLine();
                return;
            }

            int foglaltak = versenyzok.Count(v =>
                v != kivalasztott &&
                v.FoglalasKezdete.HasValue &&
                v.FoglalasVege.HasValue &&
                v.FoglalasKezdete.Value < foglalasVege &&
                v.FoglalasVege.Value > foglalasKezdete
            );

            if (foglaltak >= 20)
            {
                Console.WriteLine("\nHiba: Ez az időpont megtelt! (Max 20 fő/óra)");
                Console.ReadLine();
                return;
            }

            kivalasztott.FoglalasKezdete = foglalasKezdete;
            kivalasztott.FoglalasVege = foglalasVege;

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nSikeres foglalás / átfoglalás!");
            Console.ResetColor();
            Console.WriteLine($"Új időpont: {foglalasKezdete:yyyy.MM.dd. HH:mm} - {foglalasVege:HH:mm}");
            Console.WriteLine("\nNyomj ENTER-t a frissített táblázathoz való visszatéréshez...");
            Console.ReadLine();
        }

        static void FoglalasTorlese(List<Versenyzo> versenyzok)
        {
            Console.WriteLine("================ FOGLALÁS TÖRLÉSE ================");
            Console.Write("Add meg a versenyző azonosítóját: ");
            string azonosito = Console.ReadLine()?.Trim();

            Versenyzo kivalasztott = versenyzok.FirstOrDefault(
                v => v.VersenyzoAzonosito.Equals(azonosito, StringComparison.OrdinalIgnoreCase)
            );

            if (kivalasztott != null && kivalasztott.FoglalasKezdete.HasValue)
            {
                kivalasztott.FoglalasKezdete = null;
                kivalasztott.FoglalasVege = null;

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("\nA foglalást sikeresen töröltük!");
                Console.ResetColor();
            }
            else
            {
                Console.WriteLine("\nNem található ilyen azonosító, vagy a versenyzőnek nem volt foglalása.");
            }

            Console.WriteLine("Nyomj ENTER-t a folytatáshoz...");
            Console.ReadLine();
        }

        static string EkezetNelkul(string szoveg)
        {
            string normalizalt = szoveg.Normalize(NormalizationForm.FormD);
            return new string(
                normalizalt
                    .Where(c => CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
                    .ToArray()
            ).Normalize(NormalizationForm.FormC);
        }
    }
}